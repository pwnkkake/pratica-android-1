package com.example.aniversario4;
import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;


public class PhotoGalleryActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_gallery);


        ImageView imageView1 = findViewById(R.id.imageView1);
        imageView1.setImageResource(R.drawable.foto1);

        ImageView imageView2 = findViewById(R.id.imageView2);
        imageView2.setImageResource(R.drawable.foto2);

        ImageView imageView3 = findViewById(R.id.imageView3);
        imageView3.setImageResource(R.drawable.foto3);
    }
}
